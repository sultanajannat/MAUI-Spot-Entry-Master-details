﻿namespace MasterDetail_Api.DTO
{
    public class ClientDTO
    {
        public string ClientInfo { get; set; }
        public IFormFile? PictureFile { get; set; }
    }
}
